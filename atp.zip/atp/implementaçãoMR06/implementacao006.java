
package com.pucpr.imprementacao00;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class implementacao006 {
    
    public static class Mapperimplementacao006 extends Mapper<Object, Text, Text, LongWritable>{
        
        
        @Override
        public void map(Object chave, Text valor, Context context) throws IOException, InterruptedException{
            String linha = valor.toString();
            String[] campos = linha.split(";");
            LongWritable valorMap = new LongWritable(0);
            
             if(campos.length == 10 && campos[1].equals("2016") && campos[0].equals("Brazil")){
                String Mercadoria  = campos[3];
                String Quantidade  = campos[8];
                Text chaveMap = new Text(Mercadoria);
                
                try{
                   valorMap = new LongWritable(Long.parseLong(Quantidade));
                }catch(NumberFormatException e){
                    
                }finally{
                }
     
                context.write(chaveMap, valorMap);
            }
            
        }
        
    }
    
    public static class Reducerimplementacao006 extends Reducer<Text, LongWritable, Text, LongWritable>{
        
        @Override
        public void reduce(Text chave, Iterable<LongWritable> valores, Context context) throws IOException, InterruptedException{
            long soma = 0; 
            for(LongWritable val : valores){
                     soma += val.get();
            }
        LongWritable valorSaida = new LongWritable(soma);
        context.write(chave, valorSaida);
        }       
    }
    
    
    
    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException{
        String arquivoEntrada = "/home/Disciplinas/FundamentosBigData/OperacoesComerciais/base_inteira.csv";
        String arquivoSaida = "/home2/ead2022/SEM1/silva.michael/atp/implementaçãoMR06";
        
        if(args.length == 2){
            arquivoEntrada = args[0];
            arquivoSaida = args[1];
        }
        
    Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "atividade6");
        
        
        job.setJarByClass(implementacao006.class);
        job.setMapperClass(Mapperimplementacao006.class);
        job.setReducerClass(Reducerimplementacao006.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);
        
        FileInputFormat.addInputPath(job, new Path(arquivoEntrada));
        FileOutputFormat.setOutputPath(job, new Path(arquivoSaida));
        
        job.waitForCompletion(true);
    }
    
    
}